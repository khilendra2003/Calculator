let display = document.getElementById('display');
    let historyDiv = document.getElementById('history');
    let history = [];

    function appendToDisplay(value) {
      display.value += value;
    }

    function backspace() {
      display.value = display.value.slice(0, -1);
    }

    function clearDisplay() {
      display.value = '';
    }

    function calculate() {
      try {
        const result = eval(display.value);
        history.push(`${display.value} = ${result}`);
        display.value = result;
      } catch (error) {
        display.value = 'Error';
      }
    }

    function calculateResult() {
      calculate();
      renderHistory();
    }

    function toggleHistory() {
      if (historyDiv.style.display === 'none') {
        historyDiv.style.display = 'block';
        renderHistory();
      } else {
        historyDiv.style.display = 'none';
      }
    }

    function renderHistory() {
      historyDiv.innerHTML = '';
      history.forEach((entry, index) => {
        const p = document.createElement('p');
        p.textContent = `${index + 1}. ${entry}`;
        historyDiv.appendChild(p);
      });
    }